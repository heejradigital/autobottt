import fs from "fs";
import path from "path";
import { IgApiClient, IgCheckpointError, IgLoginTwoFactorRequiredError } from "instagram-private-api";
import { config } from "../config";
import { logger } from "../utils/logger";

export interface InstagramPublishResult {
  ok: boolean;
  skipped?: boolean;
  error?: string;
  mediaId?: string;
}

const SESSION_DIR = path.join(process.cwd(), "data", "instagram-auth");
const SESSION_FILE = path.join(SESSION_DIR, "session.json");

let igClient: IgApiClient | null = null;
let loginPromise: Promise<IgApiClient> | null = null;

function ensureSessionDir(): void {
  if (!fs.existsSync(SESSION_DIR)) {
    fs.mkdirSync(SESSION_DIR, { recursive: true });
  }
}

function truncateCaption(caption: string): string {
  const max = 2200;
  if (caption.length <= max) return caption;
  return `${caption.slice(0, max - 1)}…`;
}

async function saveSession(ig: IgApiClient): Promise<void> {
  ensureSessionDir();
  const serialized = await ig.state.serialize();
  // Remove constants to keep session file smaller / portable
  delete (serialized as { constants?: unknown }).constants;
  fs.writeFileSync(SESSION_FILE, JSON.stringify(serialized));
}

async function loadSession(ig: IgApiClient): Promise<boolean> {
  if (!fs.existsSync(SESSION_FILE)) return false;
  try {
    const raw = fs.readFileSync(SESSION_FILE, "utf8");
    await ig.state.deserialize(raw);
    await ig.user.info(ig.state.cookieUserId);
    logger.info("Instagram session restored from disk");
    return true;
  } catch (error) {
    logger.warn("Instagram session invalid — will login again", error);
    try {
      fs.unlinkSync(SESSION_FILE);
    } catch {
      // ignore
    }
    return false;
  }
}

async function loginWithPassword(ig: IgApiClient): Promise<void> {
  const username = config.instagramUsername;
  const password = config.instagramPassword;
  if (!username || !password) {
    throw new Error("INSTAGRAM_USERNAME / INSTAGRAM_PASSWORD missing");
  }

  ig.state.generateDevice(username);

  try {
    await ig.simulate.preLoginFlow();
  } catch {
    // preLoginFlow is best-effort
  }

  try {
    await ig.account.login(username, password);
  } catch (error) {
    if (error instanceof IgLoginTwoFactorRequiredError) {
      throw new Error(
        "Instagram 2FA required. Disable 2FA sementara atau guna Meta API. Checkpoint: check app IG.",
      );
    }
    if (error instanceof IgCheckpointError) {
      throw new Error(
        "Instagram checkpoint/challenge required. Buka app IG → approve login/device dulu, then restart bot.",
      );
    }
    throw error;
  }

  try {
    await ig.simulate.postLoginFlow();
  } catch {
    // postLoginFlow is best-effort
  }

  await saveSession(ig);
  logger.info("Instagram logged in", { username });
}

async function getIgClient(): Promise<IgApiClient> {
  if (igClient) return igClient;
  if (loginPromise) return loginPromise;

  loginPromise = (async () => {
    const ig = new IgApiClient();
    const username = config.instagramUsername;
    if (!username) {
      throw new Error("INSTAGRAM_USERNAME missing");
    }
    ig.state.generateDevice(username);

    const restored = await loadSession(ig);
    if (!restored) {
      await loginWithPassword(ig);
    }

    igClient = ig;
    return ig;
  })();

  try {
    return await loginPromise;
  } finally {
    loginPromise = null;
  }
}

/**
 * Publish poster + caption to Instagram feed via unofficial private API (username/password).
 * High risk of account checkpoint/ban — use at own risk.
 */
export async function publishToInstagram(
  posterFilePath: string,
  caption: string,
): Promise<InstagramPublishResult> {
  if (!config.instagramEnabled) {
    logger.info("Instagram publishing skipped (INSTAGRAM_ENABLED=false)");
    return { ok: true, skipped: true };
  }

  if (!config.instagramUsername || !config.instagramPassword) {
    return {
      ok: false,
      error: "INSTAGRAM_ENABLED=true but username/password not set",
    };
  }

  if (!fs.existsSync(posterFilePath)) {
    return { ok: false, error: `Poster not found: ${posterFilePath}` };
  }

  try {
    const ig = await getIgClient();
    const file = fs.readFileSync(posterFilePath);
    const result = await ig.publish.photo({
      file,
      caption: truncateCaption(caption),
    });

    const mediaId = String(result.media?.id ?? result.media?.pk ?? "");
    await saveSession(ig);
    logger.info("Instagram publish ok", { mediaId });
    return { ok: true, mediaId: mediaId || undefined };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    logger.error("Instagram publish failed", message);

    // Force re-login next attempt if session died
    if (/login|challenge|checkpoint|unauthorized|cookie/i.test(message)) {
      igClient = null;
      try {
        fs.unlinkSync(SESSION_FILE);
      } catch {
        // ignore
      }
    }

    return { ok: false, error: message };
  }
}
